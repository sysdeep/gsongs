#!/usr/bin/env python
# -*- coding: utf-8 -*-

# from app import app
#
# app.run(debug=True)



from app import create_app

app = create_app('default')
app.run(debug=True)