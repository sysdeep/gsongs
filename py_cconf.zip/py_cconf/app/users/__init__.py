#!/usr/bin/env python
# -*- coding: utf-8 -*-

from flask import Blueprint

users = Blueprint("users", __name__)


# after Blueprint init
from . import views

# , errors, forms