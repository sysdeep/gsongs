#!/usr/bin/env python
# -*- coding: utf-8 -*-

from datetime import datetime
from flask import request, render_template, redirect, url_for, jsonify, json
from pprint import pprint


from . import users
from .. import db
from .. models import User, Group
# from .forms import UserForm




def int_bin(val):
	vbin = "{0:08b}".format(val)
	return vbin











@users.route("/")
def index():
	# return "users /"
	return render_template("users/main.html")



@users.route("/groups", methods=['GET'])
def groups():

	groups = Group.query.all()

	# for group in groups:
	# 	print( int_bin(group.gid) )

	# return jsonify({ 'groups': [user.to_json() for user in users] })
	return json.dumps([group.to_json() for group in groups])





@users.route("/groups", methods=['POST'])
@users.route("/groups/<id>", methods=['POST'])
def group_add(id=None):

	print("group_add: "+str(id))

	# pprint(request.json)
	# pprint(json.loads(request.data))

	# data = json.loads(request.data)
	data = request.json


	if id is None:
		group = Group()
	else:
		group = Group.query.get(id)

	# print(request.values.get("name"))

	group.name = data.get("name")
	group.full_name = data.get("full_name")
	group.gid = data.get("gid")
	group.description = data.get("description")

	db.session.add(group)
	db.session.commit()

	data["id"] = group.id
	data["status"] = True

	# return jsonify({'status': True})
	return jsonify(data)


@users.route("/groups/<id>", methods=['DELETE'])
def group_del(id):

	group = Group.query.get(id)

	db.session.delete(group)
	db.session.commit()

	status = True

	return jsonify({'status': status})
	# return jsonify(data)





















@users.route("/users", methods=['GET'])
def users_all():

	users = User.query.all()

	return json.dumps([user.to_json() for user in users])






@users.route("/users", methods=['POST'])
@users.route("/users/<id>", methods=['POST'])
def user_edit(id=None):


	data = request.json

	if id is None:
		user = User()
	else:
		user = User.query.get(id)

	user.name = data.get("name")
	user.full_name = data.get("full_name")
	user.password = data.get("password")
	user.groups = data.get("groups")
	user.description = data.get("description")
	user.state = data.get("state")
	user.date_modify = datetime.utcnow()

	db.session.add(user)
	db.session.commit()

	data["id"] = user.id
	data["status"] = True

	return jsonify(data)




@users.route("/users/<id>", methods=['DELETE'])
def user_del(id):

	user = User.query.get(id)

	db.session.delete(user)
	db.session.commit()

	status = True

	return jsonify({'status': status})
	# return jsonify(data)
