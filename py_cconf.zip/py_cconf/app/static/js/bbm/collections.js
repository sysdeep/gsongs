/**
 * Created by nia on 13.01.15.
 */

var userCollection = Backbone.Collection.extend({
    model: userModel,
    url: "/users/users"
});