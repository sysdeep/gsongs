/**
 * Created by nia on 13.01.15.
 */

var userView = Marionette.ItemView.extend({
    template: _.template("<p><%= name %></p>"),
    initialize: function(){
        console.log("u view init")
    }
});



var usersView = Marionette.CollectionView.extend({
    childView: userView,

});