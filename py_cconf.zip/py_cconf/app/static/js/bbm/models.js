/**
 * Created by nia on 13.01.15.
 */

var userModel = Backbone.Model.extend({
    defaults: {
       'name': "",
       'id': 0
    },
    initialize: function(){
        console.log("user model init");
    }
});



var groupModel = Backbone.Model.extend({
    defaults: {
       'name': "",
       'id': 0
    },
    initialize: function(){
        console.log("group model init");
    }
});