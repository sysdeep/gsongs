/**
 * Created by nia on 13.01.15.
 */



var myApp = new Backbone.Marionette.Application();







myApp.on("before:start", function(options){
    console.log("before start");
});

myApp.on("start", function(options){
    console.log("start");
    if(Backbone.history){
        Backbone.history.start();
    }

    var rm = new Marionette.RegionManager();
    var regions = rm.addRegions({"mainRegion": "#mainRegion"});

    var umodel = new userModel({'name': "igor", 'id': "1"});


    var ucollection = new userCollection();
    ucollection.fetch();

    var usview = new usersView({'collection': ucollection});

    regions.mainRegion.show(usview);
    //regions.get("mainRegion").show(usview);

});


myApp.start();