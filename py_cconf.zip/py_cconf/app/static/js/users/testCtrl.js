/**
 * Created by nia on 27.12.14.
 */



(function(){

    angular.module("usersApp").controller("MainCtrl", MainCtrl);
    angular.module("usersApp").controller("FCtrl", FCtrl);
    angular.module("usersApp").controller("SCtrl", SCtrl);


    function MainCtrl($scope){
        $scope.mmm = [
            {
                "id": 1,
                "name": "Igor"
            },
            {
                "id": 2,
                "name": "Pasha"
            }
        ];
    };


    function FCtrl($scope){
        console.log( "F: ", $scope.mmm );
        var uc = this;
        uc.name = "Users";
    };

    function SCtrl($scope){
        console.log( "S:", $scope.mmm );
    };



})();