



(function(){
    "use strict";

    console.log("app main module");

    var app = angular.module("usersApp",["ngResource", "appNotify"]);

    app.config(['$interpolateProvider', function ($interpolateProvider) {
       	$interpolateProvider.startSymbol('[[');
       	$interpolateProvider.endSymbol(']]');
    }]);

    //angular.bootstrap(document, ['usersApp']);

    app.factory("Groups_service", function($resource) {
        return $resource("/users/groups/:id",{id:"@id"});
        //return $resource("/users/groups/:id", null, {
        //    "update": { method:'PUT' }
        //});
    });

    app.factory("Users_service", function($resource) {
        return $resource("/users/users/:id",{id:"@id"});
        //return $resource("/users/groups/:id", null, {
        //    "update": { method:'PUT' }
        //});
    });

})();