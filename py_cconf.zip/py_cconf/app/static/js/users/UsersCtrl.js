/**
 * Created by nia on 26.12.14.
 */

(function(){
    "use strict";

    angular.module("usersApp").controller("UsersCtrl", UsersCtrl);

    function UsersCtrl($scope, Users_service, notify){


        var uc = this;

        uc.edit_model = null;
        uc.show_form = false;





       uc.show_edit = function(model){
            model = model || null;
            uc.edit_model = model;
            uc.show_form = true;
        };

       uc.cancel_edit = function(){
            uc.show_form = false;
        };


       uc.save_edit = function(){
            Users_service.save(uc.edit_model, function(response){

                if(response.status){                        // true - ok
                    notify.n_success("Пользователь сохранена удачно")
                    uc.show_form = false;             // hide form

                    if(!uc.edit_model.id){            // new item - add to array
                        uc.edit_model.id = response.id;   // id from server
                        $scope.users.push(uc.edit_model);    // add
                    }
                }else{
                    notify.n_error("Error")
                }
            });
        };


       uc.delete_item = function(model){
            Users_service.remove(model, function(response){
                if(response.status){                    // true - ok
                    notify.n_success("Группа удалена удачно")
                    var i = $scope.users.indexOf(model);
                    $scope.users.splice(i, 1);
                }
            });
        };




        uc.sort_up = true;
        uc.sort_name = "";

       uc.sort = function(sname){
            uc.sort_name = sname;
            $scope.users.sort(function(o1, o2){
                if(uc.sort_up){
                    return o1[uc.sort_name] > o2[uc.sort_name];
                }else{
                    return o1[uc.sort_name] < o2[uc.sort_name];
                }
            });
            uc.sort_up = !uc.sort_up;
       };

       uc.test_group = function(group){
           //console.log(uc.edit_model);
           if( uc.edit_model != null ){
               return (uc.edit_model.groups & group) != 0;
           }else{
               return false;
           }
           //return (uc.edit_model.groups & group) != 0;
           //return true;
       };


        uc.change_group = function(group){
            if( uc.edit_model == null ){
                uc.edit_model = { "groups": 0};
            }else{
                if( !uc.edit_model.groups ){
                    uc.edit_model.groups = 0;
                }
            }

            if( (uc.edit_model.groups & group) != 0 ){
                uc.edit_model.groups = uc.edit_model.groups - group;
            }else{
                uc.edit_model.groups = uc.edit_model.groups + group;
            }
        };




        uc.t_group = function(a1, a2){
            return (a1 & a2) != 0;
        };




    };


})();
