/**
 * Created by nia on 26.12.14.
 */

(function(){
    "use strict";

    angular.module("usersApp").controller("MainCtrl", MainCtrl);

    function MainCtrl($scope, Groups_service, Users_service){


        var mc = this;


        mc.users_page = true;
        mc.groups_page = false;

        mc.show_users_page = function(){
            mc.users_page = true;
            mc.groups_page = false;
        };

        mc.show_groups_page = function(){
            mc.users_page = false;
            mc.groups_page = true;
        };


        $scope.groups = null;
        $scope.users = null;

        Groups_service.query(function(data) {
            $scope.groups = data;
        });

        Users_service.query(function(data){
            $scope.users = data;
        });

        //vm.users = [
        //    {
        //        "id": 1,
        //        "name": "Igor"
        //    },
        //    {
        //        "id": 2,
        //        "name": "Sasha"
        //    }
        //];



        //vm.edit_group_model = {"id": 0};
        //
        //vm.show_user_form = false;
        //vm.show_group_form = false;
        //
        //
        //vm.group_cancel_edit = function(){vm.show_group_form = false;}
        //
        //
        //vm.edit_group = function(model){
        //    model = model || null
        //    vm.edit_group_model = model;
        //    console.log(vm.edit_group_model);
        //    vm.show_group_form = true;
        //};
        //
        //
        //vm.save_group = function(){
        //    //console.log(vm.edit_group_model);
        //    Groups.save(vm.edit_group_model, function(response){
        //        //console.log(response);
        //
        //        if(response.status){                        // true - ok
        //            notify.n_success("Группа сохранена удачно")
        //            vm.show_group_form = false;             // hide form
        //            //console.log("Ok");
        //            //console.log(vm.edit_group_model);
        //            if(!vm.edit_group_model.id){            // new item - add to array
        //                //console.log("add item");
        //                vm.edit_group_model.id = response.id;   // id from server
        //                vm.groups.push(vm.edit_group_model);    // add
        //                //vm.$apply();
        //                //console.log(vm.groups);
        //            }
        //        }else{
        //            console.log("Error");
        //            notify.n_error("Error")
        //        }
        //    });
        //};
        //
        //vm.del_group = function(model){
        //    //vm.groups.remove(element);
        //    Groups.remove(model, function(response){
        //        console.log(response);
        //        if(response.status){                    // true - ok
        //            notify.n_success("Группа удалена удачно")
        //            var i = vm.groups.indexOf(model);
        //            console.log(i);
        //            //delete vm.groups[i];
        //            vm.groups.splice(i, 1);
        //            console.log(vm.groups);
        //        }
        //    });
        //};
        //
        //
        //
        //vm.sort_up = true;
        //vm.sort_name = "";
        //
        //vm.sort_group = function(sname){
        //    vm.sort_name = sname;
        //    vm.groups.sort(function(o1, o2){
        //        if(vm.sort_up){
        //            return o1[vm.sort_name] > o2[vm.sort_name];
        //        }else{
        //            return o1[vm.sort_name] < o2[vm.sort_name];
        //        }
        //    });
        //    vm.sort_up = !vm.sort_up;
        //};

    };


})();
