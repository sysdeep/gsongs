/**
 * Created by nia on 26.12.14.
 */

(function(){
    "use strict";

    angular.module("usersApp").controller("GroupsCtrl", GroupsCtrl);

    function GroupsCtrl($scope, Groups_service, notify){


        var gc = this;



        gc.edit_model = null;
        gc.show_form = false;





        gc.show_edit = function(model){
            model = model || null;
            gc.edit_model = model;
            gc.show_form = true;
        };

        gc.cancel_edit = function(){
            gc.show_form = false;
        };


        gc.save_edit = function(){
            Groups_service.save(gc.edit_model, function(response){

                if(response.status){                        // true - ok
                    notify.n_success("Группа сохранена удачно")
                    gc.show_form = false;             // hide form

                    if(!gc.edit_model.id){            // new item - add to array
                        gc.edit_model.id = response.id;   // id from server
                        $scope.groups.push(gc.edit_model);    // add
                    }
                }else{
                    console.log("Error");
                    notify.n_error("Error")
                }
            });
        };


        gc.delete_item = function(model){
            Groups_service.remove(model, function(response){
                if(response.status){                    // true - ok
                    notify.n_success("Группа удалена удачно")
                    var i = $scope.groups.indexOf(model);
                    $scope.groups.splice(i, 1);
                }
            });
        };




        gc.sort_up = true;
        gc.sort_name = "";

        gc.sort = function(sname){
            gc.sort_name = sname;
            $scope.groups.sort(function(o1, o2){
                if(gc.sort_up){
                    return o1[gc.sort_name] > o2[gc.sort_name];
                }else{
                    return o1[gc.sort_name] < o2[gc.sort_name];
                }
            });
            gc.sort_up = !gc.sort_up;
        };

    };


})();
