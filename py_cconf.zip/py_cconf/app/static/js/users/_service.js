/**
 * Created by nia on 26.12.14.
 */


(function(){
    "use strict";
    //angular.module("usersApp");

    var usersServices = angular.module("usersServices",["ngResource"]);


    usersServices.factory('User', ['$resource',
        function($resource){
            return $resource('users/:phoneId.json', {}, {
                query: {method:'GET', params:{phoneId:'phones'}, isArray:true}
            });
        }]);




})();