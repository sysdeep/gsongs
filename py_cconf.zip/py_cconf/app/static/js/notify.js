/**
 * Created by nia on 26.12.14.
 */


(function(){
    "use strict";
    //angular.module("usersApp");

    var notify = angular.module("appNotify",[]);


    notify.factory('notify', [
        function(){


            //var notify = function(text){
            //    $.notify(text);
            //};

            var notify = {
                n_info: function(text){
                    $.notify(text, {className : "info", globalPosition: "bottom right", autoHideDelay: 7000});
                },

                n_success: function(text){
                    $.notify(text, {className : "success", globalPosition: "bottom right", autoHideDelay: 7000});
                },

                n_warning: function(text){
                    $.notify(text, {className : "warn", globalPosition: "bottom right", autoHideDelay: 7000});
                },

                n_error: function(text){
                    $.notify(text, {className : "error", globalPosition: "bottom right", autoHideDelay: 7000});
                }

            };

            return notify;

        }
    ]);



    //
    //notify.factory('n_info', [
    //    function(){
    //
    //
    //        var notify = function(text){
    //            $.notify(text);
    //        };
    //
    //        return notify;
    //
    //    }
    //]);







})();