



(function(){
    "use strict";

    console.log("app main module");

    var app = angular.module("storageApp",["ngResource", "appNotify"]);

    app.config(['$interpolateProvider', function ($interpolateProvider) {
       	$interpolateProvider.startSymbol('[[');
       	$interpolateProvider.endSymbol(']]');
    }]);

    //angular.bootstrap(document, ['usersApp']);

    app.factory("Storage_service", function($resource) {
        return $resource("/storage/storage/:id",{id:"@id"});
        //return $resource("/users/groups/:id", null, {
        //    "update": { method:'PUT' }
        //});
    });

    app.factory("Category_service", function($resource) {
        return $resource("/storage/category/:id",{id:"@id"});
        //return $resource("/users/groups/:id", null, {
        //    "update": { method:'PUT' }
        //});
    });

})();