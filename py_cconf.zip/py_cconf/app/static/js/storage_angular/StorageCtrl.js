/**
 * Created by nia on 26.12.14.
 */

(function(){
    "use strict";

    angular.module("storageApp").controller("StorageCtrl", StorageCtrl);

    function StorageCtrl($scope, Storage_service, notify){


        var sc = this;



        sc.edit_model = null;
        sc.show_form = false;





        sc.show_edit = function(model){
            model = model || null;
            sc.edit_model = model;
            sc.show_form = true;
        };

        sc.cancel_edit = function(){
            sc.show_form = false;
        };


        sc.save_edit = function(){
            Storage_service.save(sc.edit_model, function(response){

                if(response.status){                        // true - ok
                    notify.n_success("Запись сохранена удачно")
                    sc.show_form = false;             // hide form

                    if(!sc.edit_model.id){              // new item - add to array
                        sc.edit_model.id = response.id;   // id from server
                        $scope.storage.push(sc.edit_model);    // add
                    }
                }else{
                    console.log("Error");
                    notify.n_error("Error")
                }
            });
        };


        sc.delete_item = function(model){
            Storage_service.remove(model, function(response){
                if(response.status){                    // true - ok
                    notify.n_success("Запись удалена удачно")
                    var i = $scope.storage.indexOf(model);
                    $scope.storage.splice(i, 1);
                }
            });
        };




        sc.sort_up = true;
        sc.sort_name = "";

        sc.sort = function(sname){
            sc.sort_name = sname;
            $scope.storage.sort(function(o1, o2){
                if(sc.sort_up){
                    return o1[sc.sort_name] > o2[sc.sort_name];
                }else{
                    return o1[sc.sort_name] < o2[sc.sort_name];
                }
            });
            sc.sort_up = !sc.sort_up;
        };


        sc.add_storage = function(category){
            console.log(category);
        };

        sc.edit_storage = function(storage){
            console.log(storage);
        }

    }
})();
