/**
 * Created by nia on 26.12.14.
 */

(function(){
    "use strict";

    angular.module("storageApp").controller("CategoryCtrl", CategoryCtrl);

    function CategoryCtrl($scope, Category_service, notify){


        var cc = this;



        cc.edit_model = null;
        cc.show_form = false;





        cc.show_edit = function(model){
            model = model || null;
            cc.edit_model = model;
            cc.show_form = true;
        };

        cc.cancel_edit = function(){
            cc.show_form = false;
        };


        cc.save_edit = function(){
            Category_service.save(cc.edit_model, function(response){

                if(response.status){                        // true - ok
                    notify.n_success("Категория сохранена удачно")
                    cc.show_form = false;             // hide form

                    if(!cc.edit_model.id){            // new item - add to array
                        cc.edit_model.id = response.id;   // id from server
                        $scope.categoryes.push(cc.edit_model);    // add
                    }
                }else{
                    console.log("Error");
                    notify.n_error("Error")
                }
            });
        };


        cc.delete_item = function(model){
            Category_service.remove(model, function(response){
                if(response.status){                    // true - ok
                    notify.n_success("Категория удалена удачно")
                    var i = $scope.categoryes.indexOf(model);
                    $scope.categoryes.splice(i, 1);
                }
            });
        };




        cc.sort_up = true;
        cc.sort_name = "";

        cc.sort = function(sname){
            cc.sort_name = sname;
            $scope.categoryes.sort(function(o1, o2){
                if(cc.sort_up){
                    return o1[cc.sort_name] > o2[cc.sort_name];
                }else{
                    return o1[cc.sort_name] < o2[cc.sort_name];
                }
            });
            cc.sort_up = !cc.sort_up;
        };


        cc.add_storage = function(category){
            console.log(category);
        };

        cc.edit_storage = function(storage){
            console.log(storage);
        }

    };


})();
