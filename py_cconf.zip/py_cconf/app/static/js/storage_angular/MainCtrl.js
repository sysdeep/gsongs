/**
 * Created by nia on 26.12.14.
 */

(function(){
    "use strict";

    angular.module("storageApp").controller("MainCtrl", MainCtrl);

    //function MainCtrl($scope, Groups_service, Users_service){
    function MainCtrl($scope, Storage_service, Category_service){


        var mc = this;


        mc.storage_page = true;
        mc.category_page = false;

        mc.show_storage_page = function(){
            mc.storage_page = true;
            mc.category_page = false;
        };

        mc.show_category_page = function(){
            mc.storage_page = false;
            mc.category_page = true;
        };


        $scope.categoryes = null;
        $scope.storage = null;

        Storage_service.query(function(data) {
            $scope.storage = data;
        });

        Category_service.query(function(data){
            $scope.categoryes = data;
        });



    }
})();
