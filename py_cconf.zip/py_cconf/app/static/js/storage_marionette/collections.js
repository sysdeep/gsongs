/**
 * Created by nia on 13.01.15.
 */

var storageCollection = Backbone.Collection.extend({
    model: storageModel,
    url: "/storage/storage"
});


var categoryCollection = Backbone.Collection.extend({
    model: categoryModel,
    url: "/storage/category"
});