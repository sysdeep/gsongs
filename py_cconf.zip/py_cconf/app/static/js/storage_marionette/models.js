/**
 * Created by nia on 13.01.15.
 */


var storageModel = Backbone.Model.extend({
    defaults: {
        "id": 0,
        "key": "",
        "value": "",
        "description": ""
    }
});



var categoryModel = Backbone.Model.extend({
    defaults: {
        "id": 0,
        "name": "",
        "description": ""
    }
});