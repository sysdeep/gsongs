/**
 * Created by nia on 13.01.15.
 */


var mainController = Marionette.Controller.extend({
    initialize: function(){
        var rm = new Marionette.RegionManager();
        this.regions = rm.addRegions({
            "mainRegion": "#mainRegion",
            "navRegion": "#navRegion"
        });

        this.nav_view = new navView();
        this.regions.navRegion.show(this.nav_view);







        this.category_collection = new categoryCollection();
        this.category_collection.fetch();


        this.storage_collection = new storageCollection();
        this.storage_collection.fetch();


        //this.on("show_category_form", function(){console.log("dddddddddddd")});
        //this.on("show_category_form", this.showCategoryForm);

    },
    category_route: function(){
        console.log("cat route");
        this.nav_view.set_active("category");

        var categoryes_view = new categoryesView({'collection': this.category_collection});
        var category_form_view = new categoryFormView();
        //this.regions.mainRegion.show(categoryes_view);
        this.category_layout = new categoryLayout();
        this.regions.mainRegion.show(this.category_layout);
        this.category_layout.main.show(categoryes_view);
        this.category_layout.add.show(category_form_view);
    },
    storage_route: function(){
        console.log("sto route");
        this.nav_view.set_active("storage");


        //var qqq = new navView();
        //this.regions.mainRegion.show(qqq);
        this.storage_layout = new storageLayout();
        this.regions.mainRegion.show(this.storage_layout);
    },

    showCategoryForm: function(){
        var category_form_view = new categoryFormView();
        this.category_layout.add.show(category_form_view);
    }
});



var storageApp = new Marionette.Application();


storageApp.addInitializer(function(options){
   this.main_controller = new mainController();
});

storageApp.on("start", function(options){
    console.log("start");





    //var main_controller =
    var router = new Marionette.AppRouter({
        controller: this.main_controller,
        appRoutes: {
            "category": "category_route",
            "storage": "storage_route"
        }
    });




    if(Backbone.history){
        Backbone.history.start();

        var ro = Backbone.history.fragment;
        console.log(ro);

        if(ro === ""){
            console.log("navgate from / to storage");
            Backbone.history.navigate("storage", {trigger: true});
            //this.main_controller.storage_route();
        }else{
            Backbone.history.navigate(ro, {trigger: true});
        }

    }

});








storageApp.start();





