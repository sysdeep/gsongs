/**
 * Created by nia on 13.01.15.
 */





var categoryLayout = Marionette.LayoutView.extend({
    template: "#layoutCategory",
    regions: {
        "main": "#c_1",
        "add": "#c_2"
    }
});


var storageLayout = Marionette.LayoutView.extend({
    template: "#layoutStorage",
    regions: {
        "main": "#s_1",
        "add": "#s_2"
    }
});




var categoryView = Marionette.ItemView.extend({
    tagName: "tr",
    template: _.template("<td><%= id %></td><td><%= name %></td><td><%= description %></td>"),
    initialize: function(){
        console.log("c view init")
    }
});



var categoryesView = Marionette.CompositeView.extend({
    childView: categoryView,
    childViewContainer: "tbody",
    template: "#categoryTable",
    events: {
        "click button#addCategory": "addCategory"
    },
    addCategory: function(){
        console.log("addCat");
        //this.trigger("show_category_form");
    }
});


var categoryFormView = Marionette.ItemView.extend({
    tagName: "div",
    template: "#categoryForm",


});





var navView = Marionette.ItemView.extend({
    template: _.template( $("#navTemplate").html() ),
    set_active: function(page){
        this.$el.find("li.active").removeClass("active");
        this.$el.find("li#nav_"+page).addClass("active");
    }
});