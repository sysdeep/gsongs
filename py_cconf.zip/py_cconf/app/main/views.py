#!/usr/bin/env python
# -*- coding: utf-8 -*-

from datetime import datetime
from flask import render_template, redirect, url_for, jsonify


from . import main
from .. import db
from .. models import User
from .forms import UserForm


@main.route("/")
def index():
	return render_template("main/main.html")




@main.route("/bbm")
def bbm():
	return render_template("main/bbm.html")

#
# @main.route("/users")
# def users():
# 	users = User.query.all()
# 	return render_template("main/users.html", users=users)
#
#
#
#
#
#
# @main.route("/users_json")
# def users_json():
# 	users = User.query.all()
# 	return jsonify({ 'users': [user.to_json() for user in users] })
#
#
#
#
#
#
# @main.route("/add_user", methods=['GET'])
# def show_add_user():
#
# 	form = UserForm()
# 	form.uid.data = None
# 	return render_template("add_user.html", form=form)
#
#
#
#
# @main.route("/add_user", methods=['POST'])
# def save_add_user():
#
# 	form = UserForm()
#
# 	form_id = form.uid.data
# 	if form_id:
# 		user = User.query.get(form_id)
# 	else:
# 		user = User()
#
# 	user.name = form.name.data
# 	user.full_name = form.full_name.data
# 	user.date_modify = datetime.utcnow()
# 	# user.level = 1
# 	# user.level_text = "admin"
# 	user.state = 1
#
# 	db.session.add(user)
# 	db.session.commit()
#
# 	return redirect(url_for('.users'))
#
#
#
#
# @main.route("/edit_user/<id>", methods=['GET'])
# def edit_user(id):
#
# 	user = User.query.get(id)
#
# 	form = UserForm()
# 	form.name.data = user.name
# 	form.full_name.data = user.full_name
# 	form.uid.data = user.id
#
# 	return render_template("add_user.html", form=form)
#
#
#
#
#
# @main.route("/delete_user/<id>", methods=['GET'])
# def delete_user(id):
#
# 	user = User.query.get(id)
# 	db.session.delete(user)
# 	db.session.commit()
#
# 	return redirect(url_for('.users'))