#!/usr/bin/env python
# -*- coding: utf-8 -*-


from flask.ext.wtf import Form
from wtforms import StringField, SubmitField, HiddenField
from wtforms.validators import Required



class UserForm(Form):
	# name = StringField('What is your name?', validators=[Required()])
	name = StringField('What is your name?')
	full_name = StringField('Full name')
	uid = HiddenField()
	submit = SubmitField('Submit')