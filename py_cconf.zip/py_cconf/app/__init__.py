#!/usr/bin/env python
# -*- coding: utf-8 -*-



from flask import Flask
# from flask.ext.sqlalchemy import SQLAlchemy
from config import config

db = SQLAlchemy()


def create_app(configName):
	app = Flask(__name__)
	# app.config.from_object(config[configName])
	# config[configName].init_app(app)

	# db.init_app(app)


	from . main import main as main_blueprint
	app.register_blueprint(main_blueprint)

	# from . users import users as users_blueprint
	# app.register_blueprint(users_blueprint, url_prefix='/users')
	#
	# from . storage import storage as storage_blueprint
	# app.register_blueprint(storage_blueprint, url_prefix='/storage')
	#
	#
	# from . api_1_0 import api10 as api10_blueprint
	# app.register_blueprint(api10_blueprint, url_prefix='/api10')


	return app

















# from flask import Flask
# from flask.ext.sqlalchemy import SQLAlchemy
#
#
# app = Flask(__name__)
# app.config.from_object('config')
# db = SQLAlchemy(app)
#
# from app import views, models
