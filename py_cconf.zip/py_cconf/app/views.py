#!/usr/bin/env python
# -*- coding: utf-8 -*-


from flask import render_template
from app import app, models


@app.route("/")
@app.route("/index")
def index():
	return "<h1>Hello Igor</h1>"



@app.route("/hello/<name>")
def hello(name):
	return render_template("1.html", name=name)
	# return "<h1>Hello %s!!</h1>" % name
