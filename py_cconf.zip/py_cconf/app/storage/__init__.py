#!/usr/bin/env python
# -*- coding: utf-8 -*-

from flask import Blueprint

storage = Blueprint("storage", __name__)


# after Blueprint init
from . import views

# , errors, forms