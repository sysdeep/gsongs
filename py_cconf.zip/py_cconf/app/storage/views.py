#!/usr/bin/env python
# -*- coding: utf-8 -*-

from datetime import datetime
from flask import request, render_template, redirect, url_for, jsonify, json
from pprint import pprint


from . import storage
from .. import db
from .. models import Storage, Category




@storage.route("/")
def index():
	# return "storage /"
	return render_template("storage_angular/main.html")
	# return render_template("storage_marionette/main.html")



@storage.route("/category", methods=['GET'])
def category_get():
	"""
	get all categoryes
	"""
	categoryes = Category.query.all()
	return json.dumps([category.to_json() for category in categoryes])


@storage.route("/storage", methods=['GET'])
def storage_get():
	"""
	get all storage
	"""
	storages = Storage.query.all()
	return json.dumps([storage.to_json() for storage in storages])






@storage.route("/category", methods=['POST'])
@storage.route("/category/<id>", methods=['POST'])
def category_add(id=None):
	"""
	add/edit category
	"""
	# print("category_add: "+str(id))

	data = request.json

	if id is None:
		category = Category()
	else:
		category = Category.query.get(id)


	category.name = data.get("name")
	category.description = data.get("description")

	db.session.add(category)
	db.session.commit()

	data["id"] = category.id
	data["status"] = True

	# return jsonify({'status': True})
	return jsonify(data)

#
@storage.route("/category/<id>", methods=['DELETE'])
def category_del(id):
	"""
	delete category
	"""
	category = Category.query.get(id)

	db.session.delete(category)
	db.session.commit()

	status = True

	return jsonify({'status': status})















@storage.route("/storage", methods=['POST'])
@storage.route("/storage/<id>", methods=['POST'])
def storage_add(id=None):
	"""
	add/edit storage
	"""

	data = request.json

	if id is None:
		storage = Storage()
	else:
		storage = Storage.query.get(id)

	# category = data.get("category")

	storage.key = data.get("key")
	storage.value = data.get("value")
	storage.description = data.get("description")
	storage.category_id = data.get("category")

	db.session.add(storage)
	db.session.commit()

	data["id"] = storage.id
	data["status"] = True

	return jsonify(data)





@storage.route("/storage/<id>", methods=['DELETE'])
def storage_del(id):
	"""
	delete storage
	"""
	storage = Storage.query.get(id)

	db.session.delete(storage)
	db.session.commit()

	status = True

	return jsonify({'status': status})




#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
#
# @users.route("/users", methods=['GET'])
# def users_all():
#
# 	users = User.query.all()
#
# 	return json.dumps([user.to_json() for user in users])
#
#
#
#
#
#
# @users.route("/users", methods=['POST'])
# @users.route("/users/<id>", methods=['POST'])
# def user_edit(id=None):
#
#
# 	data = request.json
#
# 	if id is None:
# 		user = User()
# 	else:
# 		user = User.query.get(id)
#
# 	user.name = data.get("name")
# 	user.full_name = data.get("full_name")
# 	user.password = data.get("password")
# 	user.groups = data.get("groups")
# 	user.description = data.get("description")
# 	user.state = data.get("state")
# 	user.date_modify = datetime.utcnow()
#
# 	db.session.add(user)
# 	db.session.commit()
#
# 	data["id"] = user.id
# 	data["status"] = True
#
# 	return jsonify(data)
#
#
#
#
# @users.route("/users/<id>", methods=['DELETE'])
# def user_del(id):
#
# 	user = User.query.get(id)
#
# 	db.session.delete(user)
# 	db.session.commit()
#
# 	status = True
#
# 	return jsonify({'status': status})
# 	# return jsonify(data)
