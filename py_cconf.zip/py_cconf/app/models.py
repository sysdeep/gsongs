#!/usr/bin/env python
# -*- coding: utf-8 -*-

import datetime
from app import db
# from sqlalchemy import orm

from flask import json
from pprint import pprint

# TODO: clear this file





class User(db.Model):
	__tablename__ = 'Users'
	id = db.Column(db.Integer, primary_key=True)
	name = db.Column(db.String(72))
	full_name = db.Column(db.String(72))
	password = db.Column(db.String(100))
	date_create = db.Column(db.DateTime, default=datetime.datetime.utcnow)
	date_modify = db.Column(db.DateTime)
	# level = db.Column(db.Integer)
	# level_text = db.Column(db.String(72))
	state = db.Column(db.Integer)
	groups = db.Column(db.Integer)
	description = db.Column(db.String(200))
	# groups = db.relationship('Group', backref='user', lazy='dynamic')
	# groups = db.relationship('Group', secondary=groups,
	#    backref=db.backref('user', lazy='dynamic'))

	def __repr__(self):
		return "Name: {0}".format(self.name)

	def to_json(self):
		out_json = {
			"id": self.id,
			"name": self.name,
			"full_name": self.full_name,
			"password": self.password,
			"date_create": self.date_create,
			"date_modify": self.date_modify,
			# "level": self.level,
			# "level_text": self.level_text,
			"groups": self.groups,
			"state": self.state,
			"description": self.description
		}

		return out_json


class Group(db.Model):
	__tablename__ = "Groups"
	id 			= db.Column(db.Integer, primary_key=True)
	name 		= db.Column(db.String(72))
	full_name 	= db.Column(db.String(72))
	gid 		= db.Column(db.Integer)
	description = db.Column(db.String(200))

	def to_json(self):
		out_json = {
			"id": self.id,
			"name": self.name,
			"full_name": self.full_name,
			"gid": self.gid,
			"description": self.description
		}

		return out_json

	def __repr__(self):
		return "Name: {0}".format(self.name)





class Storage(db.Model):
	__tablename__ = "Storage"
	id = db.Column(db.Integer, primary_key=True)
	key = db.Column(db.String(100))
	value = db.Column(db.String(200))
	description = db.Column(db.String(200))
	category_id = db.Column(db.Integer, db.ForeignKey("Categoryes.id"))

	def to_json(self):
		out_json = {
			"id": self.id,
			"key": self.key,
			"value": self.value,
			"description": self.description,
			"category": self.category_id
		}


		return out_json

	def __repr__(self):
		return "{0} : {1}".format(self.key, self.value)


class Category(db.Model):
	__tablename__ = "Categoryes"
	id = db.Column(db.Integer, primary_key=True)
	name 		= db.Column(db.String(72))
	description = db.Column(db.String(200))
	storages = db.relationship("Storage", backref='Categoryes', lazy='dynamic')

	def to_json(self):
		out_json = {
			"id": self.id,
			"name": self.name,
			"description": self.description
			# "sorages": self.storages
		}

		# pprint(self.storages)

		# st = json.dumps( [ss.to_json() for ss in self.storages] )
		out_json["storages"] = [ss.to_json() for ss in self.storages]

		return out_json

	def __repr__(self):
		return self.name