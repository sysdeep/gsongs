#!/usr/bin/env python
# -*- coding: utf-8 -*-

from flask import request, render_template, redirect, url_for, jsonify, json


from . import api10
from .. import db
from .. models import Storage, User

from pprint import pprint



@api10.route("/")
def index():
	apies = {
		"get_users": "get all users",
		"get_user/:id": "get user with id = id",
	}
	return json.dumps(apies)




@api10.route("/users", methods=['GET'])
@api10.route("/get_users", methods=['GET'])
def get_users():
	users = User.query.all()
	return json.dumps([user.to_json() for user in users])





@api10.route("/user/<id>", methods=['GET'])
@api10.route("/get_user/<id>", methods=['GET'])
def get_user(id):
	user = User.query.get(id)
	if user:
		data = user.to_json()
	else:
		data = ""
	return jsonify(data)



@api10.route("/user_name/<name>", methods=['GET'])
@api10.route("/get_user_name/<name>", methods=['GET'])
def get_user_name(name):
	user = User.query.filter_by(name = name).first()

	pprint(user)
	if user:
		data = user.to_json()
	else:
		data = ""
	return jsonify(data)

