#!/usr/bin/env python
# -*- coding: utf-8 -*-

from flask import Blueprint

api10 = Blueprint("api10", __name__)


# after Blueprint init
from . import views

# , errors, forms