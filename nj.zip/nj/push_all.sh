#!/bin/bash

# GitHub
git push origin master


# Openshift
git push shift master

