The Diver`s node.js application
===============================


This is simple node.js application for testing.



See here: http://nj-diver.rhcloud.com/


