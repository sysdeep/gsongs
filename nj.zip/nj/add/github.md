GitHub Readme
=============

###Access

	https://github.com/sysdeep/nj-diver.git
	git@github.com:sysdeep/nj-diver.git


###Create a new repository on the command line

	touch README.md
	git init
	git add README.md
	git commit -m "first commit"
	git remote add origin https://github.com/sysdeep/nj-diver.git
	git push -u origin master


###Push an existing repository from the command line

	git remote add origin https://github.com/sysdeep/nj-diver.git
	git push -u origin master


###Push an existing repository from the command line for this project

	git remote add github https://github.com/sysdeep/nj-diver.git
	git push -u github master