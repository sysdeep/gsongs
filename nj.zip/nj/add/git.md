Git url`s repos
===============

github
url = git@github.com:sysdeep/nj-diver.git

openshift
url = ssh://39ef231b100f446cadd4ec6237ef347c@nj-diver.rhcloud.com/~/git/nj.git/



[remote "shift"]
	url = ssh://39ef231b100f446cadd4ec6237ef347c@nj-diver.rhcloud.com/~/git/nj.git/
	fetch = +refs/heads/*:refs/remotes/origin/*



[remote "origin"]
	url = git@github.com:sysdeep/nj-diver.git
	fetch = +refs/heads/*:refs/remotes/origin/*